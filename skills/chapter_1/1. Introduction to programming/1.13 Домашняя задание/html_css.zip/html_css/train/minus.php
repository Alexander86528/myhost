<?php
$a = 5;
$b = 3;
?>
<!doctype html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Мини - сайт, математика чисел 5 и 3</title>
</head>
<body>
    <h1>Вычитание</h1>
    <p>5 - 3 = <?=$a - $b?></p>
    <a href="/">Назад
</body>
</html>