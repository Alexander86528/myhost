<!doctype html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Мини - сайт, математика чисел 5 и 3</title>
</head>
<body>
    <h1>Сложение</h1>
    <p>5 + 3 = <?=5 + 3?></p>
    <a href="/">Назад</a>
</body>
</html>