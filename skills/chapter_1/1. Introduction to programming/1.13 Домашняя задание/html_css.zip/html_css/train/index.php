<!doctype html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Мини - сайт, математика чисел 5 и 3</title>
</head>
<body>
    <h1>Математика над 5 и 3</h1>
    <ul>
        <li><a href="plus.php">Сложение</a></li>
        <li><a href="minus.php">Вычитание</a></li>
        <li><a href="multiply.php">Умножение</a></li>
        <li><a href="division.php">Деление</a></li>
    </ul>
</body>
</html>